# Power BI Dashboard Build Guide

## Project context
This is a portfolio practice project using a simulated dataset of 5,000 e-commerce orders. It does not represent a real company.

## 1. Import the data
1. Open Power BI Desktop on a Windows computer.
2. Select **Get data > Text/CSV**.
3. Select `data/ecommerce_orders.csv`.
4. Choose **Transform Data**.
5. Set `order_date`, `shipped_date`, and `delivered_date` to Date data types.
6. Set `order_amount_ngn` and `unit_price_ngn` to Decimal Number.
7. Set `quantity` and `delivery_days` to Whole Number.
8. Select **Close & Apply**.
9. Rename the table to `ecommerce_orders` if Power BI assigned another name.

## 2. Create measures
Use the formulas in `power_bi/measures.dax`. In Power BI Desktop, select the table, choose **New measure**, and add each measure.

## 3. Recommended one-page dashboard layout

### Header
Title: **E-commerce Sales & Delivery Performance**
Subtitle: **Portfolio analysis | Simulated 2025 order data**

### KPI cards across the top
- Total Orders
- Delivered Revenue (NGN)
- Delivered Orders
- Cancellation Rate
- Average Delivery Days

### Main visuals
1. **Clustered column chart:** Delivered Revenue (NGN) by `product_category`.
2. **Line chart:** Delivered Revenue (NGN) by month from `order_date` (filter to Delivered status).
3. **Bar chart:** Cancellation Rate by `delivery_city`.
4. **Donut chart:** Order count by `order_status`.
5. **Bar chart:** Total Orders by `payment_method`.

### Slicers
- `order_date`
- `product_category`
- `delivery_city`
- `payment_method`

## 4. Design guidance
- Use a clean, uncluttered layout.
- Keep currency consistently in NGN (₦).
- Use clear titles and readable labels.
- Avoid implying that simulated results are real business performance.
- Add a small footer: **Synthetic dataset created for portfolio demonstration.**

## 5. Phone limitation
Power BI mobile is primarily for viewing and interacting with reports, not building a full report from scratch. The actual `.pbix` report should be authored in Power BI Desktop on a Windows computer. These prepared measures and layout instructions let us complete the report when desktop access is available.

## 6. Publish
When the `.pbix` file is complete, save it in this project folder and upload it to the GitHub repository. Publish to Power BI Service only if you choose to share a report link, and check sharing permissions before making it public.
